import React, { useState } from 'react';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import ordersData from '../data/orders.json';

const puestos = Array.from({ length: 17 }, (_, i) => `Puesto ${i + 1}`);

function OrderBoard() {
  const [puestosData, setPuestosData] = useState(
    puestos.reduce((acc, puesto) => {
      acc[puesto] = [];
      return acc;
    }, {})
  );

  const [orders, setOrders] = useState(ordersData);

  const onDragEnd = (result) => {
    const { source, destination, draggableId } = result;
    if (!destination) return;

    const order = orders.find(o => o.id === draggableId);

    const newSource = Array.from(puestosData[source.droppableId]);
    newSource.splice(result.source.index, 1);

    const newDest = Array.from(puestosData[destination.droppableId]);
    newDest.splice(result.destination.index, 0, order);

    setPuestosData({
      ...puestosData,
      [source.droppableId]: newSource,
      [destination.droppableId]: newDest
    });
  };

  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <div style={{ display: 'flex', flexWrap: 'wrap' }}>
        {puestos.map(puesto => (
          <Droppable droppableId={puesto} key={puesto}>
            {(provided) => (
              <div
                ref={provided.innerRef}
                {...provided.droppableProps}
                style={{
                  margin: '10px',
                  padding: '10px',
                  width: '250px',
                  minHeight: '200px',
                  backgroundColor: '#f0f0f0'
                }}
              >
                <h3>{puesto}</h3>
                {puestosData[puesto].map((order, index) => (
                  <Draggable draggableId={order.id} index={index} key={order.id}>
                    {(provided) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        {...provided.dragHandleProps}
                        style={{
                          padding: '8px',
                          margin: '4px',
                          backgroundColor: '#fff',
                          border: '1px solid #ccc',
                          ...provided.draggableProps.style
                        }}
                      >
                        <strong>{order.id}</strong>: {order.descripcion} ({order.horas}h)
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        ))}
      </div>
    </DragDropContext>
  );
}

export default OrderBoard;