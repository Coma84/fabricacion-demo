import React from 'react';
import OrderBoard from './components/OrderBoard';

function App() {
  return (
    <div>
      <h1>Gestión de Órdenes de Fabricación</h1>
      <OrderBoard />
    </div>
  );
}

export default App;